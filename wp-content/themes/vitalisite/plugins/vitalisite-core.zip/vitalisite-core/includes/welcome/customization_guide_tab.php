<?php

function display_customization_guide() {
    echo '<h1>Commencez la personnalisation</h1>';
    echo '<p>Allez dans le <a href="' . admin_url('customize.php') . '">Personnalisateur</a> pour modifier l’apparence de votre site.</p>';
}